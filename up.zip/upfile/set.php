<?php
/////////
$auto = 'http://xtgem.com/autologin/c37237dd57eebc705e24603187639fd0/dm4zeC55bi5sdA==';
/////////
$tenwap = explode('/',$auto);
$server = $tenwap[2];
$tenwap = base64_decode($tenwap[5]);
$ua = 'Opera/9.80 (J2ME/MIDP; Opera Mini/9.80 (S60; SymbOS; Opera Mobi/23.348; U; en) Presto/2.5.25 Version/10.54';
$cookies = 'cooki.txt';
$wap4 = 'http://upfree.viwap.com';
?>