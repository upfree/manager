<?php
set_time_limit(1000);
include 'set.php';
include 'function.php';
$url = isset($_POST['url']) ? $_POST['url'] : NULL;
if ($url != NULL) {
$idfb = $_POST['idfb'];
$token = trim($_POST['token']);
$name = basename($url);
$types = pathinfo($url, PATHINFO_EXTENSION);
$typee = array('jpg','mp3','png','jpeg','mp4','3gp','exe','gif','zip','js','apk','jar','jad','avi','pdf');
$checktoken = trim(file_get_contents($wap4.'/check.php?id='.$idfb));
$size = strlen(file_get_contents($url));
if (!isURL($url)) {
echo 'Url không hợp lệ';
header("Location: ".$wap4."/error?type=notopen");
}
elseif ($checktoken != $token) {
header("Location: ".$wap4."/error?type=token");
echo 'Token sai';
}
elseif ($size > 15728639)
{
header("Location: ".$wap4."/error?type=maxsize");  
echo 'File quA dung luong';
}
else if(strlen($name) < '3'){
header("Location: ".$wap4."/error?type=notopen");
Echo 'ngan';
}
elseif(!in_array($types,$typee)) {
header("Location: ".$wap4."/error?type=notopen");
Echo 'File không hợp lệ';
}
else if(import($url,'folder/'.$name)) {
$type = mime_content_type('folder/'.$name);
$size = filesize('folder/'.$name);
$fp = @fopen('folder/'.$name, "r");
// Kiểm tra file mở thành công không
if (!$fp) {
header("Location: ".$wap4."/error?type=notopen");  
echo 'Mở file không thành công';
}
else
{
// Đọc file và trả về nội dung
$namefolder = rand_text(30);
$data = fread($fp, filesize('folder/'.$name));
$filename = trim(filename($name,$type));
////upload/////
tao_tm('/upload',$namefolder);
tao_file('/upload/'.$namefolder.'/'.$filename,$data);
tao_w4($idfb,$token,$namefolder,$filename,$type,$size,$pass,$mota);
unlink('folder/'.$name);
$id = file_get_contents('id.txt');
header("Location: ".$wap4."/files/".$id);  
echo $id;
echo 'Upload thanh cong';
}
}
} else {
echo 'Chưa nhập url';
header("Location: ".$wap4."/error?type=nofile");
}