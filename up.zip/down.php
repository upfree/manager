<?php 
// by Minh Nhí
$wap4 = 'http://upfree.viwap.com';
$id = isset($_GET['id']) ? $_GET['id'] : '';
$url = urldecode(trim(file_get_contents($wap4.'/down?id='.$id)));
$url = str_replace(' ', '+', $url);
function down($url,$id,$wap4) {
$type = trim(file_get_contents($wap4.'/down?type='.$id));
$namefile = trim(file_get_contents($wap4.'/down?name='.$id));
$size = trim(file_get_contents($wap4.'/down?size='.$id));
// File type
header('Content-Type: '.$type);
// File name
header('Content-Disposition: attachment; filename='.$namefile);
header('Content-Length: '. $size);
// File output
readfile($url);
}
if(filter_var($url, FILTER_VALIDATE_URL) === false) exit(header('Location: '.$wap4.'/error?type=notopen'));
$ch = curl_init($url); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$html = curl_exec($ch);
curl_close($ch);
preg_match('/xthotlink\=(.*?)\"/', $html, $match);
if(!$match) exit(down($url,$id,$wap4));
header('Location: '.$url.'?xthotlink='.$match[1]); 
?>